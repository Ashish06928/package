﻿using System;

namespace HBCLogin
{
    public class Login
    {
        public string UserLogin(string userName,string password)
        {
            if(userName==password)
            {
                return "true";
            }
            else
            {
                return "false";
            }
        }
    }
}
